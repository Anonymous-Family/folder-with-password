# lock-windows-folder-with-password

disable your antivirus

open the txt file 

serch for "if NOT %pass%== YOUR-PASSWORD goto FAIL" line and replace 'YOUR-PASSWORD' with your desired password

save the file as batch "bat" file with the folder you want to lock in the same level

click the bat file and a folder called private will be created in the same level with your two previous folders

put files you want to secure in the private folder

click the bat file and enter y in the cmd prompt

#access locked files

disable antivirus

click the bat file

type your password in the cmd prompt

wallah (:)
